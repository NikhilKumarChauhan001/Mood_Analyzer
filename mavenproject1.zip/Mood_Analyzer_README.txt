MOOD ANALYZER
Research has shown that social networking activity is a good source to gauge a person�s state of mind. Mood of a user is often reflected in his/her social content, like tweets, blogs, article, status updates, etc. Timely analysis of a user�s social media can be used to improve the feelings, and even save a person�s life in an extreme case!

A person�s emotions and moods have direct bearings on his/her daily activities. It is necessary to eliminate negative emotions that our family or friends might be experiencing, to help them lead a better life

MOOD ANALYZER helps to understand human mental state better by RECOGNITION via FACIAL EXPRESSION n Text , helps in eliminating any negative state of mind that might have adverse effect on his/her daily life by providing SOLUTIONS.

Technologies used :
1 Microsoft Azure
2 IBM Watson
3 My SQL
4 jdk 10 (maven project)
5 NetBeans IDE
6 Google Cloud Service

* Photos taken from google images